import React from "react"
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

// --- METADATA ---
export const metadata: Metadata = {
  title: 'Good Night Good Dream', 
  description: 'Interactive animated character with shader effects',
  generator: 'v0.app',
  icons: {

    icon: 'https://images2.imgbox.com/a0/4f/br9iVI3r_o.png',

    apple: 'https://images2.imgbox.com/a0/4f/br9iVI3r_o.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#000000',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}

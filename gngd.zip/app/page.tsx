import MeshGradientSVG from "@/components/mesh-gradient-svg"

export default MeshGradientSVG

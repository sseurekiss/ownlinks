"use client"

import React from "react"
import { motion, useMotionValue, useSpring, useTransform, AnimatePresence } from "framer-motion"
import { useCallback, useEffect, useRef, useState, useMemo } from "react"

export default function Home() {
  const [debouncedEyeOffset, setDebouncedEyeOffset] = useState({ x: 0, y: 0 })
  const svgRef = useRef<SVGSVGElement>(null)
  const mouseX = useMotionValue(Number.POSITIVE_INFINITY)

  // Memoized social links
  const socialLinks = useMemo(() => [
    { 
      name: "Letterboxd", 
      url: "https://letterboxd.com/eyesbleu/",
      icon: "https://images2.imgbox.com/0b/77/XHlKFo7A_o.png"
    },
    { 
      name: "Facebook", 
      url: "https://www.facebook.com/ekslqnel",
      icon: "https://images2.imgbox.com/e3/cb/IbCmAmz7_o.png"
    },
    { 
      name: "Threads", 
      url: "https://www.threads.net/@ekslqnel", 
      icon: "https://images2.imgbox.com/a6/bf/XlymHZe0_o.png"
    }, 
    { 
      name: "TikTok", 
      url: "https://tiktok.com/@ekslqnel",
      icon: "https://images2.imgbox.com/ff/0b/q2iqL68e_o.png"
    },
    { 
      name: "X", 
      url: "https://x.com/ekslqnel",
      icon: "https://images2.imgbox.com/4a/d2/bLM0H3V3_o.png"
    },
    { 
      name: "Instagram", 
      url: "https://instagram.com/ekslqnel",
      icon: "https://images2.imgbox.com/69/4d/yFLay5nn_o.png"
    },
    { 
      name: "Last.fm", 
      url: "https://www.last.fm/user/eyesbleu",
      icon: "https://images2.imgbox.com/2a/10/5gcXx0f8_o.png"
    },
  ], [])

  // Optimized eye tracking
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!svgRef.current) return

    const rect = svgRef.current.getBoundingClientRect()
    const centerX = rect.left + rect.width / 2
    const centerY = rect.top + rect.height / 2
    
    const deltaX = (e.clientX - centerX) * 0.08
    const deltaY = (e.clientY - centerY) * 0.08
    const maxOffset = 8
    
    setDebouncedEyeOffset({
      x: Math.max(-maxOffset, Math.min(maxOffset, deltaX)),
      y: Math.max(-maxOffset, Math.min(maxOffset, deltaY)),
    })

    mouseX.set(e.pageX)
  }, [mouseX])

  useEffect(() => {
    const handleMouseLeave = () => {
      mouseX.set(Number.POSITIVE_INFINITY)
      setDebouncedEyeOffset({ x: 0, y: 0 })
    }
    window.addEventListener("mousemove", handleMouseMove, { passive: true })
    window.addEventListener("mouseleave", handleMouseLeave, { passive: true })
    
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [handleMouseMove, mouseX])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center overflow-hidden relative w-full" style={{
      backgroundImage: 'url(https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%2045.png-h6uq4cOSDSQM3FfYhUgJS3Vd7D2uxp.jpeg)',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      {/* Overlay for better readability */}
      <div className="absolute inset-0 bg-black/10" />
      
      {/* Main Character */}
      <motion.div
        className="relative z-10 w-full max-w-xs sm:max-w-sm md:max-w-lg px-3 sm:px-4 md:px-8 py-3 sm:py-6 md:py-8 rounded-lg pointer-events-none mb-12 sm:mb-16 md:mb-20 will-change-transform"
        animate={{
          y: [0, -8, 0], // Slightly increased float range for ghost effect
        }}
        transition={{
          duration: 6,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
        style={{ transformOrigin: "top center" }}
      >
        <svg 
          ref={svgRef}
          xmlns="http://www.w3.org/2000/svg" 
          width="231" 
          height="289" 
          viewBox="0 0 231 289" 
          className="w-full h-auto drop-shadow-2xl"
          role="img"
          aria-label="Interactive animated ghost character"
        >
          <defs>
            {/* 1. Ghost Gradient: Top (White/Opaque) -> Bottom (Transparent) */}
            <linearGradient id="ghostGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgba(255, 255, 255, 0.9)" />
              <stop offset="50%" stopColor="rgba(240, 240, 250, 0.4)" />
              <stop offset="100%" stopColor="rgba(255, 255, 255, 0.1)" />
            </linearGradient>

            <clipPath id="shapeClip">
              <path d="M230.809 115.385V249.411C230.809 269.923 214.985 287.282 194.495 288.411C184.544 288.949 175.364 285.718 168.26 280C159.746 273.154 147.769 273.461 139.178 280.23C132.638 285.384 124.381 288.462 115.379 288.462C106.377 288.462 98.1451 285.384 91.6055 280.23C82.912 273.385 70.9353 273.385 62.2415 280.23C55.7532 285.334 47.598 288.411 38.7246 288.462C17.4132 288.615 0 270.667 0 249.359V115.385C0 51.6667 51.6756 0 115.404 0C179.134 0 230.809 51.6667 230.809 115.385Z" />
            </clipPath>
            
            <radialGradient id="eyeWhiteGradient" cx="35%" cy="35%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="70%" stopColor="#F5F5F5" />
              <stop offset="100%" stopColor="#E8E8E8" />
            </radialGradient>
            
            <radialGradient id="glossedPupil" cx="30%" cy="30%">
              <stop offset="0%" stopColor="rgba(255, 255, 255, 0.6)" />
              <stop offset="40%" stopColor="rgba(26, 26, 26, 0.8)" />
              <stop offset="100%" stopColor="#000000" />
            </radialGradient>
            
            <radialGradient id="shadowGradient" cx="50%" cy="50%">
              <stop offset="0%" stopColor="#000000" stopOpacity="0" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.15" />
            </radialGradient>
          </defs>

          {/* Ghost Body Shape
            - Replaced <rect> with <path> to allow proper stroking without clipping issues
            - Uses 'ghostGradient' for the transparent/white look
            - Added stroke for definition 
          */}
          <path 
            d="M230.809 115.385V249.411C230.809 269.923 214.985 287.282 194.495 288.411C184.544 288.949 175.364 285.718 168.26 280C159.746 273.154 147.769 273.461 139.178 280.23C132.638 285.384 124.381 288.462 115.379 288.462C106.377 288.462 98.1451 285.384 91.6055 280.23C82.912 273.385 70.9353 273.385 62.2415 280.23C55.7532 285.334 47.598 288.411 38.7246 288.462C17.4132 288.615 0 270.667 0 249.359V115.385C0 51.6667 51.6756 0 115.404 0C179.134 0 230.809 51.6667 230.809 115.385Z" 
            fill="url(#ghostGradient)" 
            stroke="rgba(255, 255, 255, 0.4)"
            strokeWidth="1.5"
            className="backdrop-blur-sm" // Optional: adds slight blur if supported by browser/renderer
          />

          {/* Left Eye */}
          <g>
            <circle cx="80" cy="120" r="25" fill="url(#shadowGradient)" />
            <circle cx="80" cy="120" r="24" fill="url(#eyeWhiteGradient)" stroke="#D0D0D0" strokeWidth="1" className="animate-blink" />
            <motion.circle
              cx={80}
              cy={120}
              r="12"
              fill="url(#glossedPupil)"
              className="animate-blink"
              animate={{
                cx: Math.max(76, Math.min(84, 80 + debouncedEyeOffset.x)),
                cy: Math.max(116, Math.min(124, 120 + debouncedEyeOffset.y)),
              }}
              transition={{ type: "spring", stiffness: 120, damping: 20 }}
            />
          </g>

          {/* Right Eye */}
          <g>
            <circle cx="150" cy="120" r="25" fill="url(#shadowGradient)" />
            <circle cx="150" cy="120" r="24" fill="url(#eyeWhiteGradient)" stroke="#D0D0D0" strokeWidth="1" className="animate-blink" />
            <motion.circle
              cx={150}
              cy={120}
              r="12"
              fill="url(#glossedPupil)"
              className="animate-blink"
              animate={{
                cx: Math.max(146, Math.min(154, 150 + debouncedEyeOffset.x)),
                cy: Math.max(116, Math.min(124, 120 + debouncedEyeOffset.y)),
              }}
              transition={{ type: "spring", stiffness: 120, damping: 20 }}
            />
          </g>
        </svg>

        <style jsx>{`
          .animate-blink {
            animation: blink 4s infinite ease-in-out;
          }
          @keyframes blink {
            0%, 90%, 100% { ry: 30; }
            95% { ry: 3; }
          }
        `}</style>
      </motion.div>

      {/* Dock with Icons */}
      <motion.div 
        onMouseMove={(e) => mouseX.set(e.pageX)}
        onMouseLeave={() => mouseX.set(Number.POSITIVE_INFINITY)}
        className="fixed bottom-3 sm:bottom-6 md:bottom-12 left-1/2 transform -translate-x-1/2 flex items-end gap-2 sm:gap-3 md:gap-6 px-2 sm:px-4 py-3 z-50"
      >
        {socialLinks.map((link) => (
          <DockIcon 
            key={link.name} 
            mouseX={mouseX} 
            link={link} 
          />
        ))}
      </motion.div>
    </div>
  )
}

// Memoized Dock Icon Component
const DockIcon = React.memo(function DockIcon({ mouseX, link }: any) {
  const ref = useRef<HTMLAnchorElement>(null)
  const [hovered, setHovered] = useState(false)

  const distance = useTransform(mouseX, (val: number) => {
    const bounds = ref.current?.getBoundingClientRect() ?? { x: 0, width: 0 }
    return val - bounds.x - bounds.width / 2
  })

  const sizeSync = useTransform(distance, [-120, 0, 120], [40, 70, 40])
  const size = useSpring(sizeSync, { mass: 0.2, stiffness: 120, damping: 18 })

  return (
    <motion.a
      ref={ref}
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      style={{ width: size, height: size }} 
      className="relative flex items-center justify-center group cursor-pointer flex-shrink-0 will-change-transform"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <AnimatePresence mode="wait">
        {hovered && (
          <motion.div
            initial={{ opacity: 0, y: -10, x: "-50%" }}
            animate={{ opacity: 1, y: -60, x: "-50%" }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute top-0 left-1/2 px-2 sm:px-3 py-1 sm:py-1.5 bg-gray-900/90 backdrop-blur-md text-white text-[9px] sm:text-[10px] font-medium tracking-wide rounded-lg border border-white/10 whitespace-nowrap pointer-events-none shadow-xl z-50"
          >
            {link.name}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.img
        src={link.icon}
        alt={link.name}
        loading="lazy"
        className="w-full h-full object-contain filter brightness-100 hover:brightness-110 transition-all duration-300"
        whileHover={!hovered ? {} : { 
          rotate: 3,
          transition: { 
            duration: 0.4,
            ease: "easeInOut"
          } 
        }}
      />
    </motion.a>
  )
})
